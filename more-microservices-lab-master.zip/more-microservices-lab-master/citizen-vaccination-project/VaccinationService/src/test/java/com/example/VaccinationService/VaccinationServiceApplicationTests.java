package com.example.VaccinationService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VaccinationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
